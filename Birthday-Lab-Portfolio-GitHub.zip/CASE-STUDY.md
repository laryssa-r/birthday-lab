# Birthday Lab — narrativa e interação em uma experiência de celebração

**Tipo:** projeto demonstrativo para portfólio.

**Objetivo:** criar uma sequência leve e interativa que funcione bem no celular, usando capítulos em vez de uma página longa.

## Decisões de experiência

A entrada apresenta uma confirmação lúdica para introduzir o personagem fictício. O primeiro toque pode iniciar o som, respeitando o comportamento de reprodução dos navegadores. Durante os capítulos, o usuário encontra cartões, escolhas, galeria e mudanças de ritmo visual.

A tipografia, as cores claras e as composições ilustradas criam uma linguagem próxima de um álbum editorial. A etapa de reconhecimento desacelera a experiência; o encerramento retoma a interação com um jogo curto.

## Soluções implementadas

Os textos são dados separados dos componentes, o que facilita a adaptação para novos temas. O áudio é compartilhado entre etapas. Os capítulos permanecem montados para preservar os estados das interações; o jogo para quando seu capítulo deixa de estar ativo.

Ilustrações em SVG e uma animação abstrata substituem mídias pessoais. A cópia demonstrativa é independente da experiência que a inspirou.

## Colaboração com IA

A implementação e os ajustes foram realizados com assistência de IA e revisão humana. A apresentação do projeto deve descrever as decisões, os testes e a curadoria efetivamente realizados, sem atribuir métricas ou pesquisa que não aconteceram.

## Evidências e limites

A entrega inclui o código editável e uma versão estática pronta para publicação. Compilação, renderização de capítulos, referências de mídia e busca de conteúdo privado são verificadas na preparação. Testes em celulares reais continuam sendo uma etapa recomendada.
