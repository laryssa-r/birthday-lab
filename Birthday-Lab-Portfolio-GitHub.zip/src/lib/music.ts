import { useEffect, useState } from "react";
import { siteConfig } from "../content/media";
let audio: HTMLAudioElement | null = null;
const listeners = new Set<() => void>();
let missing = false;
let enabled = false;
const notify = () => listeners.forEach(fn => fn());
function getAudio() {
  if (!audio) {
    audio = new Audio(siteConfig.musicSrc); audio.loop = true; audio.volume = 0.4;
    audio.addEventListener("play", notify); audio.addEventListener("pause", notify);
    audio.addEventListener("error", () => { missing = true; notify(); });
    document.addEventListener("play", e => { if (e.target instanceof HTMLVideoElement) audio?.pause(); }, true);
    const resume = (e: Event) => {
      if (!(e.target instanceof HTMLVideoElement) || !enabled) return;
      if (!Array.from(document.querySelectorAll("video")).some(v => !v.paused && !v.ended)) audio?.play().catch(() => {});
    };
    document.addEventListener("pause", resume, true);
    document.addEventListener("ended", resume, true);
  }
  return audio;
}
export function startMusic() { enabled = true; missing = false; getAudio().play().then(notify).catch(() => { missing = true; notify(); }); }
export function useMusic() {
  const [, redraw] = useState(0);
  useEffect(() => { const fn = () => redraw(n => n + 1); listeners.add(fn); return () => { listeners.delete(fn); }; }, []);
  return { playing: !!audio && !audio.paused, missing, toggle: () => { const a = getAudio(); if (a.paused) startMusic(); else { enabled = false; a.pause(); } } };
}
