/**
 * Mini confete em canvas (sem dependências).
 * Respeita prefers-reduced-motion (não faz nada nesse caso).
 */

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  rot: number;
  vr: number;
  color: string;
  emoji?: string;
  life: number;
  shape: "rect" | "circle";
}

const PALETTE = ["#E9B95B", "#B76D75", "#F5D7CF", "#F8EBCB", "#9A555D", "#FFFFFF"];

export function prefersReducedMotion(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export interface BurstOptions {
  /** posição em pixels de viewport; padrão: centro-baixo */
  x?: number;
  y?: number;
  count?: number;
  emojis?: string[];
  spread?: number;
  power?: number;
}

export function burst(opts: BurstOptions = {}): void {
  if (typeof document === "undefined" || prefersReducedMotion()) return;

  const w = window.innerWidth;
  const h = window.innerHeight;
  const x = opts.x ?? w / 2;
  const y = opts.y ?? h * 0.6;
  const count = opts.count ?? 70;
  const spread = opts.spread ?? Math.PI * 1.1;
  const power = opts.power ?? 1;

  const canvas = document.createElement("canvas");
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  canvas.setAttribute("aria-hidden", "true");
  Object.assign(canvas.style, {
    position: "fixed",
    inset: "0",
    width: "100%",
    height: "100%",
    pointerEvents: "none",
    zIndex: "9999",
  });
  document.body.appendChild(canvas);
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    canvas.remove();
    return;
  }
  ctx.scale(dpr, dpr);

  const particles: Particle[] = Array.from({ length: count }, (_, i) => {
    const angle = -Math.PI / 2 + (Math.random() - 0.5) * spread;
    const speed = (6 + Math.random() * 9) * power;
    const useEmoji = opts.emojis && opts.emojis.length > 0 && i % 3 === 0;
    return {
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      size: useEmoji ? 18 + Math.random() * 10 : 6 + Math.random() * 6,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 0.35,
      color: PALETTE[Math.floor(Math.random() * PALETTE.length)],
      emoji: useEmoji ? opts.emojis![Math.floor(Math.random() * opts.emojis!.length)] : undefined,
      life: 1,
      shape: Math.random() > 0.6 ? "circle" : "rect",
    };
  });

  const start = performance.now();
  const duration = 2200;

  const frame = (now: number) => {
    const t = now - start;
    ctx.clearRect(0, 0, w, h);
    for (const p of particles) {
      p.vy += 0.28;
      p.vx *= 0.992;
      p.x += p.vx;
      p.y += p.vy;
      p.rot += p.vr;
      p.life = Math.max(0, 1 - t / duration);
      ctx.save();
      ctx.globalAlpha = Math.min(1, p.life * 1.6);
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      if (p.emoji) {
        ctx.font = `${p.size}px system-ui, "Apple Color Emoji", "Segoe UI Emoji", sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(p.emoji, 0, 0);
      } else {
        ctx.fillStyle = p.color;
        if (p.shape === "circle") {
          ctx.beginPath();
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
        }
      }
      ctx.restore();
    }
    if (t < duration) {
      requestAnimationFrame(frame);
    } else {
      canvas.remove();
    }
  };
  requestAnimationFrame(frame);
}

/** Dispara o confete a partir do centro de um elemento (ex.: botão clicado) */
export function burstFrom(el: Element | null, opts: BurstOptions = {}): void {
  if (!el) return burst(opts);
  const r = el.getBoundingClientRect();
  burst({ ...opts, x: r.left + r.width / 2, y: r.top + r.height / 2 });
}

export function vibrate(ms = 15): void {
  if (typeof navigator !== "undefined" && "vibrate" in navigator) {
    try {
      navigator.vibrate(ms);
    } catch {
      /* ignora */
    }
  }
}
