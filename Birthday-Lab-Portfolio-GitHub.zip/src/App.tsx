import { GiftChapter } from "./components/chapters/GiftChapter";
import { useCallback, useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, List, Music, VolumeX, X } from "lucide-react";
import { AlbumViewer, type AlbumItem } from "./components/AlbumViewer";
import { Intro } from "./components/Intro";
import { AdmireChapter } from "./components/chapters/AdmireChapter";
import { FilesChapter } from "./components/chapters/FilesChapter";
import { FinalChapter } from "./components/chapters/FinalChapter";
import { HistoryChapter } from "./components/chapters/HistoryChapter";
import { HoldingChapter } from "./components/chapters/HoldingChapter";
import { QuirksChapter } from "./components/chapters/QuirksChapter";
import { ReasonsChapter } from "./components/chapters/ReasonsChapter";
import { SpaChapter } from "./components/chapters/SpaChapter";
import { WhoChapter } from "./components/chapters/WhoChapter";
import { Button } from "./components/ui/Button";
import { chapters } from "./content/chapters";
import { useMusic } from "./lib/music";
import { cn } from "./utils/cn";

type AlbumState = { items: AlbumItem[]; start: number } | null;

function Experience({ onRestart }: { onRestart: () => void }) {
  const [idx, setIdx] = useState(0);
  const [visited, setVisited] = useState<number[]>([0]);
  const [menu, setMenu] = useState(false);
  const [album, setAlbum] = useState<AlbumState>(null);
  const music = useMusic();

  const total = chapters.length;

  const go = useCallback(
    (n: number) => {
      const next = Math.max(0, Math.min(total - 1, n));
      document.querySelectorAll("video").forEach((v) => v.pause());
      setIdx(next);
      setVisited((v) => (v.includes(next) ? v : [...v, next]));
      setMenu(false);
      window.scrollTo(0, 0);
    },
    [total],
  );

  useEffect(() => {
    if (!menu) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setMenu(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menu]);

  const openAlbum = useCallback((items: AlbumItem[], start: number) => setAlbum({ items, start }), []);
  const closeAlbum = useCallback(() => setAlbum(null), []);

  const renderChapter = (i: number) => {
    switch (chapters[i].id) {
      case "quem":
        return <WhoChapter />;
      case "holding":
        return <HoldingChapter />;
      case "manias":
        return <QuirksChapter />;
      case "arquivos":
        return <FilesChapter />;
      case "spa":
        return <SpaChapter />;
      case "historia":
        return <HistoryChapter onOpenAlbum={openAlbum} />;
      case "admiro":
        return <AdmireChapter />;
      case "motivos":
        return <ReasonsChapter onFinal={() => go(chapters.findIndex(c => c.id === "final"))} />;
      case "presente":
        return <GiftChapter active={idx === i} onOpenAlbum={openAlbum} onRestart={onRestart} />;
      default:
        return <FinalChapter onOpenAlbum={openAlbum} onChallenge={() => go(chapters.findIndex(c => c.id === "presente"))} active={idx === i} />;
    }
  };

  const ch = chapters[idx];
  const pct = ((idx + 1) / total) * 100;

  return (
    <div className="min-h-dvh transition-colors duration-1000 ease-in-out" style={{ backgroundColor: ch.bg }}>
      {/* Topo */}
      <header className="sticky top-0 z-40 border-b border-cocoa/5 bg-cream/75 pt-[env(safe-area-inset-top)] backdrop-blur-md">
        <div className="h-1 w-full bg-cocoa/10" role="progressbar" aria-valuemin={1} aria-valuemax={total} aria-valuenow={idx + 1} aria-label="Progresso da experiência">
          <div className="h-full rounded-r-full bg-gradient-to-r from-butter to-rose transition-all duration-700 ease-out" style={{ width: `${pct}%` }} />
        </div>
        <div className="mx-auto flex max-w-xl items-center gap-2 px-3 py-2">
          <button
            type="button"
            onClick={() => setMenu(true)}
            className="grid size-11 place-items-center rounded-full text-cocoa hover:bg-cocoa/5"
            aria-label="Abrir lista de capítulos"
          >
            <List size={22} />
          </button>
          <div className="min-w-0 flex-1 leading-tight">
            <p className="truncate text-[0.68rem] font-bold uppercase tracking-widest text-cocoa-soft">
              ALEX 2.8 · {idx + 1}/{total}
            </p>
            <p className="truncate font-display text-[1.05rem] font-semibold">{ch.short}</p>
          </div>
          <div className="relative">
            <button
              type="button"
              onClick={music.toggle}
              className={cn("grid size-11 place-items-center rounded-full transition-colors", music.playing ? "bg-butter text-cocoa" : "text-cocoa hover:bg-cocoa/5")}
              aria-label={music.playing ? "Desligar música" : "Ligar música"}
              aria-pressed={music.playing}
            >
              {music.playing ? <Music size={20} /> : <VolumeX size={20} />}
            </button>
            {music.missing && (
              <p role="status" className="animate-fade-in absolute right-0 top-12 w-56 rounded-xl bg-cocoa px-3 py-2 text-xs leading-snug text-cream shadow-soft">
                Música não encontrada. Use o botão para tentar novamente.
              </p>
            )}
          </div>
        </div>
      </header>

      {/* Capítulos (mantidos montados para preservar o progresso de cada um) */}
      <div className="mx-auto max-w-xl px-5 py-3 text-center text-xs text-cocoa-soft">DEMONSTRAÇÃO DE PORTFÓLIO · Personagem, mensagens e cenas fictícios.</div>
      <main className="pb-28">
        {chapters.map((c, i) =>
          visited.includes(i) ? (
            <div key={c.id} hidden={i !== idx}>
              {renderChapter(i)}
            </div>
          ) : null,
        )}
      </main>

      {/* Navegação inferior */}
      <nav
        aria-label="Navegação entre capítulos"
        className="fixed inset-x-0 bottom-0 z-40 bg-gradient-to-t from-cream via-cream/90 to-transparent pb-[max(0.9rem,env(safe-area-inset-bottom))] pt-8"
      >
        <div className="mx-auto flex max-w-xl items-center gap-3 px-5">
          <Button variant="ghost" disabled={idx === 0} onClick={() => go(idx - 1)} aria-label="Capítulo anterior" icon={<ArrowLeft size={18} aria-hidden />} className="shadow-soft">
            Voltar
          </Button>
          {idx < total - 1 ? (
            <Button variant="primary" className="flex-1" onClick={() => go(idx + 1)}>
              <span className="truncate">Próximo: {chapters[idx + 1].short}</span>
              <ArrowRight size={18} aria-hidden />
            </Button>
          ) : (
            <Button variant="butter" className="flex-1" onClick={() => go(0)}>
              Voltar ao início
            </Button>
          )}
        </div>
      </nav>

      {/* Menu de capítulos */}
      {menu && (
        <div className="animate-fade-in fixed inset-0 z-[60] bg-cocoa/50 backdrop-blur-sm" onClick={() => setMenu(false)}>
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Capítulos"
            className="animate-slide-down mx-auto mt-[max(1rem,env(safe-area-inset-top))] max-h-[88dvh] w-[calc(100%-1.5rem)] max-w-md overflow-y-auto rounded-3xl bg-cream p-4 shadow-polaroid"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-2 pb-2">
              <p className="font-display text-xl font-semibold">Capítulos</p>
              <button type="button" onClick={() => setMenu(false)} className="grid size-10 place-items-center rounded-full hover:bg-cocoa/5" aria-label="Fechar">
                <X size={20} />
              </button>
            </div>
            <ol className="space-y-1.5">
              {chapters.map((c, i) => (
                <li key={c.id}>
                  <button
                    type="button"
                    onClick={() => go(i)}
                    aria-current={i === idx ? "step" : undefined}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left transition-colors",
                      i === idx ? "bg-butter font-bold" : "hover:bg-peach-soft",
                    )}
                  >
                    <span className={cn("grid size-8 shrink-0 place-items-center rounded-full text-sm font-bold", i === idx ? "bg-cocoa text-butter" : visited.includes(i) ? "bg-rose text-white" : "bg-cocoa/10")}>
                      {i + 1}
                    </span>
                    <span className="font-display text-[1.05rem] leading-tight">{c.title}</span>
                  </button>
                </li>
              ))}
            </ol>
            <button type="button" onClick={onRestart} className="mt-3 w-full rounded-2xl px-3 py-3 text-center text-sm font-semibold text-cocoa-soft hover:bg-peach-soft">
              Recomeçar a experiência
            </button>
          </div>
        </div>
      )}

      {album && <AlbumViewer items={album.items} startIndex={album.start} onClose={closeAlbum} />}
    </div>
  );
}

export default function App() {
  const [started, setStarted] = useState(false);
  const [run, setRun] = useState(0);

  const restart = useCallback(() => {
    setStarted(false);
    setRun((r) => r + 1);
    window.scrollTo(0, 0);
  }, []);

  if (!started) return <Intro key={run} onStart={() => { setStarted(true); window.scrollTo(0, 0); }} />;
  return <Experience key={run} onRestart={restart} />;
}
