import { startMusic } from "../lib/music";
import { useEffect, useState } from "react";
import { Bot, Check, ShieldCheck, Sparkles } from "lucide-react";
import { gate, loadingSteps, title } from "../content/intro";
import { burst } from "../lib/confetti";
import { cn } from "../utils/cn";
import { Button } from "./ui/Button";

type Stage = "gate" | "loading" | "title";

function Backdrop() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute -left-24 -top-24 size-72 rounded-full bg-peach/70 blur-3xl" />
      <div className="absolute -right-20 top-1/3 size-64 rounded-full bg-butter-soft blur-3xl" />
      <div className="absolute -bottom-24 left-1/4 size-72 rounded-full bg-peach-soft blur-3xl" />
    </div>
  );
}

export function Intro({ onStart }: { onStart: () => void }) {
  const [stage, setStage] = useState<Stage>("gate");

  return (
    <div className="relative min-h-dvh overflow-hidden bg-cream">
      <Backdrop />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-5 py-8">
        {stage === "gate" && <Gate onConfirm={() => { startMusic(); setStage("loading"); }} />}
        {stage === "loading" && <Loading onDone={() => setStage("title")} />}
        {stage === "title" && <TitleReveal onStart={onStart} />}
      </div>
    </div>
  );
}

function Gate({ onConfirm }: { onConfirm: () => void }) {
  const [checked, setChecked] = useState<boolean[]>(gate.options.map(() => false));
  const any = checked.some(Boolean);

  return (
    <div className="animate-fade-up">
      <p className="birthday-alert mx-auto mb-6 w-fit rounded-lg bg-butter px-6 py-3 text-center text-lg font-extrabold tracking-widest">⚠ ATENÇÃO!!!</p>
      {/* Bolha de mensagem automática, no estilo de chat */}
      <div className="mb-1 flex items-center gap-2 px-1 text-xs font-bold uppercase tracking-widest text-cocoa-soft">
        <span className="grid size-6 place-items-center rounded-full bg-cocoa text-butter">
          <Bot size={14} aria-hidden />
        </span>
        {gate.robotLabel}
      </div>
      <div className="relative rounded-2xl rounded-tl-sm bg-white p-5 shadow-soft ring-1 ring-cocoa/5">
        <p className="font-display text-[1.9rem] font-semibold leading-tight">{gate.greeting}</p>
        {gate.lines.map((l) => (
          <p key={l} className="mt-2 leading-relaxed text-cocoa-soft">
            {l}
          </p>
        ))}
        <ul className="mt-4 space-y-1.5 rounded-xl bg-butter-soft/70 p-3.5 text-[0.92rem]">
          <li>
            📦 <strong>Versão:</strong> {gate.version}
          </li>
          <li>
            🔐 <strong>Destinatário:</strong> {gate.recipient}
          </li>
          <li>
            ⚠️ <strong>Classificação:</strong> {gate.classification}
          </li>
        </ul>
        <p className="mt-4 font-medium leading-relaxed">{gate.before}</p>
      </div>

      {/* Verificação */}
      <fieldset className="paper shadow-soft mt-5 rounded-3xl p-5 ring-1 ring-cocoa/5">
        <legend className="sr-only">Verificação de identidade</legend>
        <p className="flex items-center gap-2 font-display text-lg font-semibold">
          <ShieldCheck size={20} className="text-rose" aria-hidden />
          {gate.question}
        </p>
        <div className="mt-3 space-y-2.5">
          {gate.options.map((opt, i) => (
            <label
              key={opt}
              className={cn(
                "flex cursor-pointer items-start gap-3 rounded-2xl border-2 p-3.5 text-[0.95rem] leading-snug transition-all active:scale-[0.99]",
                checked[i] ? "border-rose bg-peach-soft" : "border-cocoa/10 bg-white/70 hover:border-rose/40",
              )}
            >
              <input
                type="checkbox"
                className="sr-only"
                checked={checked[i]}
                onChange={() => setChecked((c) => c.map((v, j) => (j === i ? !v : v)))}
              />
              <span
                aria-hidden="true"
                className={cn(
                  "mt-0.5 grid size-6 shrink-0 place-items-center rounded-lg border-2 transition-all",
                  checked[i] ? "scale-105 border-rose bg-rose text-white" : "border-cocoa/25 bg-white",
                )}
              >
                {checked[i] && <Check size={15} strokeWidth={3} />}
              </span>
              <span>{opt}</span>
            </label>
          ))}
        </div>
        <p className="mt-3 text-sm text-cocoa-soft" aria-live="polite">
          {any ? "Identidade quase confirmada." : gate.hint}
        </p>
        <Button variant="rose" block className="mt-4" disabled={!any} onClick={onConfirm}>
          {gate.button}
        </Button>
      </fieldset>

      <p className="mt-5 text-center text-xs italic text-cocoa-soft">{gate.footer}</p>
    </div>
  );
}

function Loading({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (step >= loadingSteps.length - 1) {
      const t = setTimeout(onDone, 1100);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setStep((s) => s + 1), 1050);
    return () => clearTimeout(t);
  }, [step, onDone]);

  const pct = Math.round((step / (loadingSteps.length - 1)) * 100);
  const done = step >= loadingSteps.length - 1;

  return (
    <div className="animate-fade-in text-center">
      <div className="mx-auto grid size-20 place-items-center rounded-3xl bg-cocoa text-butter shadow-soft">
        {done ? <Sparkles size={34} className="animate-pop" /> : <Bot size={34} className="animate-float" />}
      </div>
      <p className="mt-6 font-hand text-3xl text-rose">Atualizando para</p>
      <p className="font-display text-4xl font-semibold">{gate.version}</p>

      <div
        className="mx-auto mt-7 h-4 w-full overflow-hidden rounded-full bg-peach ring-1 ring-cocoa/10"
        role="progressbar"
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="Progresso da atualização"
      >
        <div className="stripes h-full rounded-full bg-rose transition-all duration-1000 ease-out" style={{ width: `${Math.max(pct, 6)}%` }} />
      </div>
      <p className="mt-2 text-sm font-semibold text-cocoa-soft">{pct}%</p>

      <ul className="mt-6 space-y-2 text-left" aria-live="polite">
        {loadingSteps.slice(0, step + 1).map((s, i) => {
          const last = i === step;
          const finalMsg = i === loadingSteps.length - 1;
          return (
            <li
              key={s}
              className={cn(
                "animate-fade-up flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[0.95rem]",
                finalMsg ? "bg-butter font-bold" : last ? "bg-white font-semibold shadow-soft" : "text-cocoa-soft",
              )}
            >
              <span
                className={cn(
                  "grid size-5 shrink-0 place-items-center rounded-full text-[10px]",
                  last && !finalMsg ? "animate-pulse-soft bg-rose text-white" : "bg-cocoa text-cream",
                )}
              >
                {last && !finalMsg ? "•" : <Check size={12} strokeWidth={3} />}
              </span>
              {s}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function TitleReveal({ onStart }: { onStart: () => void }) {
  useEffect(() => {
    const t = setTimeout(() => burst({ count: 90, y: window.innerHeight * 0.45 }), 350);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="text-center">
      <p className="animate-fade-up font-hand text-3xl text-rose">{title.eyebrow}</p>
      <h1 className="animate-fade-up mt-1 font-display text-[4rem] font-bold leading-[0.9] tracking-tight [animation-delay:150ms]">
        ALEX
        <span className="mt-1 block text-[5.5rem] text-rose">2.8</span>
      </h1>
      <div className="animate-stamp mx-auto mt-4 w-fit rounded-md bg-butter px-4 py-1.5 font-display text-lg font-bold uppercase tracking-[0.2em] [animation-delay:500ms]">
        {title.sub}
      </div>
      <p className="animate-fade-up mx-auto mt-6 max-w-xs font-display text-[1.15rem] italic leading-snug text-cocoa-soft [animation-delay:700ms]">
        {title.tagline}
      </p>

      <div className="animate-fade-up paper shadow-soft mx-auto mt-6 rounded-2xl p-4 text-left text-sm ring-1 ring-cocoa/5 [animation-delay:900ms]">
        <p className="font-bold">{title.notes[0]}</p>
        <ul className="mt-2 space-y-1 text-cocoa-soft">
          {title.notes.slice(1).map((n) => (
            <li key={n}>{n}</li>
          ))}
        </ul>
      </div>

      <div className="animate-fade-up mt-7 [animation-delay:1100ms]">
        <Button variant="primary" block onClick={onStart} className="min-h-14 text-base">
          {title.button}
        </Button>
      </div>
    </div>
  );
}
