import { useEffect, useRef, useState } from "react";
import { Button } from "./ui/Button";

type Point = { x: number; y: number };
type Direction = "up" | "down" | "left" | "right";
type State = "ready" | "playing" | "lost" | "won";
const N = 12;
const GOAL = 10;
const vectors: Record<Direction, Point> = { up: { x: 0, y: -1 }, down: { x: 0, y: 1 }, left: { x: -1, y: 0 }, right: { x: 1, y: 0 } };
const initial = () => [{ x: 4, y: 6 }, { x: 3, y: 6 }, { x: 2, y: 6 }];

export function SnakeGame({ active }: { active: boolean }) {
  const [body, setBody] = useState<Point[]>(initial);
  const [food, setFood] = useState<Point>({ x: 7, y: 6 });
  const [score, setScore] = useState(0);
  const [state, setState] = useState<State>("ready");
  const model = useRef({ body: initial(), food: { x: 7, y: 6 }, score: 0, dir: "right" as Direction, next: "right" as Direction });
  const touch = useRef<Point | null>(null);
  const steer = (direction: Direction) => {
    const now = vectors[model.current.dir], next = vectors[direction];
    if (now.x + next.x !== 0 || now.y + next.y !== 0) model.current.next = direction;
  };
  useEffect(() => {
    if (!active && state === "playing") setState("ready");
    if (!active || state !== "playing") return;
    const key = (e: KeyboardEvent) => {
      const direction = ({ ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right" } as Record<string, Direction>)[e.key];
      if (direction) { e.preventDefault(); steer(direction); }
    };
    window.addEventListener("keydown", key);
    const timer = window.setInterval(() => {
      const m = model.current;
      m.dir = m.next;
      const v = vectors[m.dir], head = { x: m.body[0].x + v.x, y: m.body[0].y + v.y };
      const eat = head.x === m.food.x && head.y === m.food.y;
      const occupied = eat ? m.body : m.body.slice(0, -1);
      if (head.x < 0 || head.y < 0 || head.x >= N || head.y >= N || occupied.some(p => p.x === head.x && p.y === head.y)) { setState("lost"); return; }
      m.body = [head, ...m.body];
      if (eat) {
        m.score += 1;
        if (m.score === GOAL) setState("won");
        else {
          const free: Point[] = [];
          for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (!m.body.some(p => p.x === x && p.y === y)) free.push({ x, y });
          m.food = free[Math.floor(Math.random() * free.length)];
        }
      } else m.body.pop();
      setBody([...m.body]); setFood({ ...m.food }); setScore(m.score);
    }, 190);
    return () => { window.clearInterval(timer); window.removeEventListener("keydown", key); };
  }, [active, state]);
  const start = () => {
    model.current = { body: initial(), food: { x: 7, y: 6 }, score: 0, dir: "right", next: "right" };
    setBody(initial()); setFood({ x: 7, y: 6 }); setScore(0); setState("playing");
  };
  return <section className="paper shadow-soft rounded-3xl p-5 ring-1 ring-rose/20 sm:p-7" aria-label="Jogo da cobrinha">
    <p className="font-hand text-3xl text-rose">Desafio final da demonstração</p>
    <h3 className="mt-2 font-display text-2xl font-semibold">Consegue pegar 10 corações?</h3>
    <p className="mt-2 text-sm text-cocoa-soft">Use as setas, os botões ou deslize no tabuleiro. Não bata nas paredes nem em você mesmo.</p>
    <p className="my-4 text-center font-bold" aria-live="polite">{state === "lost" ? "Bateu! Pode tentar de novo." : state === "won" ? "10 de 10! Conseguiu!" : `${score} / ${GOAL} corações`}</p>
    <div className="tribute-snake-board" role="img" aria-label={`Tabuleiro da cobrinha: ${score} de ${GOAL} corações`} onTouchStart={e => { touch.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }; }} onTouchEnd={e => {
      if (!touch.current) return;
      const dx = e.changedTouches[0].clientX - touch.current.x, dy = e.changedTouches[0].clientY - touch.current.y;
      if (Math.max(Math.abs(dx), Math.abs(dy)) > 15) steer(Math.abs(dx) > Math.abs(dy) ? dx > 0 ? "right" : "left" : dy > 0 ? "down" : "up");
      touch.current = null;
    }}>{Array.from({ length: N * N }, (_, i) => { const x = i % N, y = Math.floor(i / N), index = body.findIndex(p => p.x === x && p.y === y), heart = state !== "won" && food.x === x && food.y === y; return <span key={i} className={index === 0 ? "snake-head" : index > 0 ? "snake-body" : heart ? "snake-heart" : ""}>{heart ? "♥" : ""}</span>; })}</div>
    <div className="tribute-snake-pad">
      <button aria-label="Cima" onClick={() => steer("up")}>↑</button>
      <div>{(["left", "down", "right"] as Direction[]).map((d, i) => <button key={d} aria-label={d === "left" ? "Esquerda" : d === "right" ? "Direita" : "Baixo"} onClick={() => steer(d)}>{["←", "↓", "→"][i]}</button>)}</div>
    </div>
    {state !== "playing" && <Button variant="butter" block onClick={start}>{state === "ready" ? "Jogar" : "Jogar de novo"}</Button>}
    {state === "won" && <div className="mt-5 rounded-2xl bg-butter-soft p-5 text-center" role="status"><h4 className="font-hand text-3xl text-rose">Missão concluída!</h4><p className="mt-2">Você coletou os dez corações e concluiu a experiência. Em uma versão personalizada, este estado pode apresentar uma mensagem de celebração ou uma surpresa autorizada.</p></div>}
  </section>;
}
