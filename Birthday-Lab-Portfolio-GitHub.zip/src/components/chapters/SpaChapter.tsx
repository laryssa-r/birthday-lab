import { useState } from "react";
import { demoBreaks } from "../../content/spa";
import { ChapterShell, Card } from "../ui/ChapterShell";
import { Button } from "../ui/Button";

export function SpaChapter() {
  const [selected, setSelected] = useState<string | null>(null);
  return <ChapterShell number="Capítulo 05" title="Pausa criativa" intro="Uma mudança de ritmo também pode fazer parte da narrativa."><Card><p className="font-hand text-3xl text-rose">Qual intervalo você escolhe?</p><div className="mt-5 flex flex-col gap-3">{demoBreaks.map(text => <Button key={text} variant="ghost" onClick={() => setSelected(text)}>{text}</Button>)}</div>{selected && <div className="animate-pop mt-5 rounded-2xl bg-butter-soft p-5 text-center" role="status"><p className="font-bold">Pausa reservada.</p><p className="mt-2">{selected}. Quando quiser, continue para o próximo capítulo.</p></div>}</Card></ChapterShell>;
}
