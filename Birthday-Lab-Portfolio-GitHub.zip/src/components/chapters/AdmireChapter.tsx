import { useState } from "react";
import { ArrowLeft, ArrowRight, Moon, Sun } from "lucide-react";
import { admireClosing, admireIntro, admireSteps } from "../../content/emotion";
import { media } from "../../content/media";
import { burst } from "../../lib/confetti";
import { cn } from "../../utils/cn";
import { Button } from "../ui/Button";
import { ChapterShell } from "../ui/ChapterShell";
import { Polaroid } from "../ui/Polaroid";

export function AdmireChapter() {
  const [stage, setStage] = useState<"intro" | "switching" | "steps" | "end">("intro");
  const [i, setI] = useState(0);

  const turnOff = () => {
    setStage("switching");
    setTimeout(() => setStage("steps"), 900);
  };

  if (stage === "intro" || stage === "switching") {
    const off = stage === "switching";
    return (
      <ChapterShell number="Capítulo 07" title="Reconhecer o caminho">
        <div className="paper shadow-soft rounded-3xl p-6 text-center ring-1 ring-cocoa/5">
          <p className="font-display text-2xl font-semibold leading-snug">{admireIntro.title}</p>
          <p className="mt-3 leading-relaxed text-cocoa-soft">{admireIntro.text}</p>

          <button
            type="button"
            role="switch"
            aria-checked={off}
            aria-label="Modo comédia"
            onClick={turnOff}
            disabled={off}
            className={cn(
              "relative mx-auto mt-6 flex h-16 w-36 items-center rounded-full p-1.5 shadow-inner ring-1 ring-cocoa/10 transition-colors duration-700",
              off ? "bg-rose/30" : "bg-butter",
            )}
          >
            <span
              className={cn(
                "grid size-12 place-items-center rounded-full bg-white shadow-md transition-transform duration-700 ease-out",
                off ? "translate-x-[4.5rem]" : "translate-x-0",
              )}
            >
              {off ? <Moon size={22} className="text-rose" aria-hidden /> : <Sun size={22} className="text-butter" aria-hidden />}
            </span>
          </button>
          <p className="mt-3 text-sm font-bold text-cocoa-soft">Modo comédia: {off ? "desligando…" : "ligado"}</p>
          {!off && (
            <Button variant="rose" className="mt-5" onClick={turnOff}>
              {admireIntro.button}
            </Button>
          )}
        </div>
      </ChapterShell>
    );
  }

  const step = admireSteps[Math.min(i, admireSteps.length - 1)];
  const last = i >= admireSteps.length - 1;

  if (stage === "end") {
    return (
      <ChapterShell number="Capítulo 07" title="Reconhecer o caminho">
        <div className="animate-pop rounded-3xl bg-white/80 p-7 text-center shadow-soft ring-1 ring-rose/20">
          <p className="font-display text-[1.6rem] font-medium italic leading-snug text-cocoa [text-wrap:balance]">“{admireClosing}”</p>
          <p className="mt-4 font-hand text-3xl text-rose">Equipe Aurora</p>
        </div>
        <div className="flex justify-center">
          <Button variant="ghost" onClick={() => { setStage("steps"); setI(0); }}>
            Reler do começo
          </Button>
        </div>
      </ChapterShell>
    );
  }

  return (
    <ChapterShell number="Capítulo 07" title="Reconhecer o caminho">
      <div className="mx-auto w-full max-w-[17rem]" key={step.slot}>
        <div className="animate-pop">
          <Polaroid slot={media[step.slot]} caption={step.kicker} rotate={i % 2 === 0 ? -2 : 2} tape={i % 2 === 0 ? "butter" : "rose"} />
        </div>
      </div>

      <div key={i} className="animate-fade-up min-h-[11rem] rounded-3xl bg-white/80 p-6 shadow-soft ring-1 ring-rose/15" aria-live="polite">
        <p className="font-hand text-2xl leading-none text-rose">{step.kicker}</p>
        <p className="mt-2 font-display text-[1.3rem] font-medium leading-snug text-cocoa">{step.text}</p>
      </div>

      <div className="flex items-center justify-between gap-3">
        <Button
          variant="ghost"
          disabled={i === 0}
          aria-label="Frase anterior"
          onClick={() => setI((v) => Math.max(0, v - 1))}
          icon={<ArrowLeft size={18} aria-hidden />}
        >
          Voltar
        </Button>
        <div className="flex gap-1.5" aria-hidden>
          {admireSteps.map((_, k) => (
            <span key={k} className={cn("h-1.5 rounded-full transition-all", k === i ? "w-6 bg-rose" : k < i ? "w-1.5 bg-rose/60" : "w-1.5 bg-cocoa/20")} />
          ))}
        </div>
        <Button
          variant="rose"
          onClick={() => {
            if (last) {
              setStage("end");
              burst({ count: 40, emojis: ["🤍"], power: 0.8 });
            } else setI((v) => v + 1);
          }}
        >
          {last ? "Concluir" : "Continuar"} <ArrowRight size={18} aria-hidden />
        </Button>
      </div>
    </ChapterShell>
  );
}
