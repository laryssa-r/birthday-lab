import { useState } from "react";
import { Dices } from "lucide-react";
import { media } from "../../content/media";
import { professionsOfTheDay, realTraits, sheet, skills, whoQuote } from "../../content/who";
import { burstFrom } from "../../lib/confetti";
import { Button } from "../ui/Button";
import { Card, ChapterShell, PullQuote } from "../ui/ChapterShell";
import { FlipCard } from "../ui/FlipCard";
import { Polaroid } from "../ui/Polaroid";
import { SkillIcon } from "../ui/SkillIcon";

export function WhoChapter() {
  const [prof, setProf] = useState<string | null>(null);
  const [flipped, setFlipped] = useState<Record<string, boolean>>({});
  const count = Object.values(flipped).filter(Boolean).length;
  const everFlipped = Object.keys(flipped).length;

  return (
    <ChapterShell
      number="Capítulo 01"
      title="Quem é Alex?"
      intro="Ficha de um personagem inteiramente fictício, criada para demonstrar cartões e estados de interação."
    >
      <div className="relative">
        <div className="grid grid-cols-[8.5rem_1fr] items-start gap-4">
          <div className="-rotate-3">
            <Polaroid slot={media.avatar} caption="Versão 2.8" rotate={0} className="p-2 pb-3" />
          </div>
          <div className="pt-1">
            <p className="font-hand text-2xl leading-none text-rose">Personagem</p>
            <p className="font-display text-4xl font-bold leading-none">Alex</p>
            <span className="mt-2 inline-block rounded-full bg-cocoa px-3 py-1 text-xs font-bold tracking-widest text-butter">
              NÍVEL 28
            </span>
          </div>
        </div>
      </div>

      <Card className="!p-0 overflow-hidden">
        <dl className="divide-y divide-cocoa/10">
          {sheet.map((row) => (
            <div key={row.label} className="grid grid-cols-[6.5rem_1fr] gap-3 px-5 py-3">
              <dt className="text-xs font-bold uppercase tracking-wider text-cocoa-soft">{row.label}</dt>
              <dd className="font-semibold leading-snug">{row.value}</dd>
            </div>
          ))}
        </dl>
        <div className="bg-peach-soft/70 px-5 py-4">
          <p className="mb-2 text-xs font-bold uppercase tracking-wider text-cocoa-soft">Características do personagem</p>
          <ul className="flex flex-wrap gap-2">
            {realTraits.map((t) => (
              <li key={t} className="rounded-full bg-white px-3 py-1.5 text-sm font-semibold shadow-sm ring-1 ring-cocoa/10">
                {t}
              </li>
            ))}
          </ul>
        </div>
      </Card>

      <Card className="text-center">
        <p className="text-sm font-semibold text-cocoa-soft">Profissão: depende do dia. Qual é a de hoje?</p>
        {prof && (
          <p key={prof} className="animate-pop mt-3 font-display text-2xl font-semibold leading-tight text-rose-deep">
            {prof}
          </p>
        )}
        <Button
          variant="butter"
          className="mt-4"
          icon={<Dices size={18} aria-hidden />}
          onClick={(e) => {
            let next = prof;
            while (next === prof) next = professionsOfTheDay[Math.floor(Math.random() * professionsOfTheDay.length)];
            setProf(next);
            burstFrom(e.currentTarget, { count: 22, power: 0.7 });
          }}
        >
          Sortear profissão de hoje
        </Button>
      </Card>

      <div>
        <div className="mb-3 flex items-end justify-between">
          <h3 className="font-display text-2xl font-semibold">Habilidades</h3>
          <span className="text-sm font-semibold text-cocoa-soft" aria-live="polite">
            {count}/{skills.length} reveladas
          </span>
        </div>
        <p className="mb-3 text-sm text-cocoa-soft">Toque em um cartão para revelar.</p>
        <div className="grid grid-cols-2 gap-3">
          {skills.map((s, i) => (
            <FlipCard
              key={s.id}
              label={`Habilidade: ${s.name}`}
              className="min-h-[10.5rem]"
              onFlip={(f) => setFlipped((p) => ({ ...p, [s.id]: f }))}
              frontClassName="paper shadow-soft ring-1 ring-cocoa/5 flex h-full min-h-[10.5rem] flex-col items-center justify-center gap-3 p-4 text-center"
              backClassName="flex h-full min-h-[10.5rem] items-center justify-center bg-cocoa p-4 text-center text-[0.9rem] font-medium leading-snug text-cream shadow-soft"
              front={
                <>
                  <span
                    className={`grid size-14 place-items-center rounded-2xl ${i % 3 === 0 ? "bg-butter-soft text-cocoa" : i % 3 === 1 ? "bg-peach text-rose-deep" : "bg-cocoa text-butter"}`}
                  >
                    <SkillIcon name={s.icon} />
                  </span>
                  <span className="font-display text-lg font-semibold">{s.name}</span>
                  <span className="text-[0.7rem] font-medium uppercase tracking-wider text-cocoa-soft">Toque para revelar</span>
                </>
              }
              back={<>{s.back}</>}
            />
          ))}
        </div>
        {everFlipped > 0 && count === skills.length && (
          <p className="animate-pop mt-4 rounded-2xl bg-butter px-4 py-3 text-center text-sm font-bold">
            Todas as habilidades reveladas. Ainda faltam as que ele aprender semana que vem.
          </p>
        )}
      </div>

      <PullQuote>{whoQuote}</PullQuote>
    </ChapterShell>
  );
}
