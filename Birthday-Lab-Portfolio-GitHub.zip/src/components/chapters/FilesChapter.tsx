import { useState } from "react";
import { demoStories, filesIntro } from "../../content/files";
import { media } from "../../content/media";
import { ChapterShell } from "../ui/ChapterShell";
import { Polaroid } from "../ui/Polaroid";

export function FilesChapter() {
  const [opened, setOpened] = useState<number | null>(null);
  return <ChapterShell number="Capítulo 04" title="Pequenos imprevistos" intro={filesIntro}>
    {demoStories.map((story, i) => <div key={story.title} className="paper rounded-3xl p-5 shadow-soft"><button className="flex min-h-12 w-full items-center justify-between text-left font-display text-xl" aria-expanded={opened === i} onClick={() => setOpened(opened === i ? null : i)}>{story.title}<span aria-hidden>{opened === i ? "−" : "+"}</span></button>{opened === i && <div className="animate-fade-up mt-5 space-y-5"><p>{story.text}</p><Polaroid slot={[media.skyline, media.kitchen, media.tripPhoto][i]} caption="Cena fictícia ilustrada" /></div>}</div>)}
  </ChapterShell>;
}
