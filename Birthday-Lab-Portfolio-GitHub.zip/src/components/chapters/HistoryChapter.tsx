import { ExtraMemories } from "../ExtraMemories";
import { Images, Lock } from "lucide-react";
import { duneTeaser, historyIntro, memories } from "../../content/history";
import { media } from "../../content/media";
import type { AlbumItem } from "../AlbumViewer";
import { Button } from "../ui/Button";
import { ChapterShell } from "../ui/ChapterShell";
import { Polaroid } from "../ui/Polaroid";
import { Reveal } from "../ui/Reveal";

export const historyAlbumItems: AlbumItem[] = memories.flatMap((m) => m.items.filter(it => media[it.slot].src));

interface Props {
  onOpenAlbum: (items: AlbumItem[], start: number) => void;
}

export function HistoryChapter({ onOpenAlbum }: Props) {
  let flat = -1;
  return (
    <ChapterShell number="Capítulo 06" title="Uma história fictícia" intro={historyIntro}>
      <Button variant="ghost" icon={<Images size={18} aria-hidden />} onClick={() => onOpenAlbum(historyAlbumItems, 0)}>
        Abrir como álbum
      </Button>

      <ol className="relative space-y-12 border-l-2 border-dashed border-rose/40 pl-6">
        {memories.map((m, mi) => (
          <li key={m.id} className="relative">
            <span
              aria-hidden
              className="absolute -left-[2.1rem] top-1 grid size-5 place-items-center rounded-full bg-butter ring-4 ring-cream"
            >
              <span className="size-1.5 rounded-full bg-cocoa" />
            </span>
            <Reveal>
              <p className="font-hand text-2xl leading-none text-rose">{m.num}</p>
              <h3 className="mt-1 font-display text-[1.75rem] font-semibold leading-tight">{m.title}</h3>
              <p className="mt-2 text-[0.98rem] leading-relaxed text-cocoa-soft">{m.text}</p>
            </Reveal>

            <div className="mt-5 space-y-8">
              {m.items.filter(it => media[it.slot].src).map((it, ii) => {
                flat += 1;
                const idx = flat;
                const slot = media[it.slot];
                const rot = (mi + ii) % 2 === 0 ? -2 : 2;
                return (
                  <Reveal key={it.slot} delay={ii * 80}>
                    <div className={slot.type === "video" ? "mx-auto max-w-[17rem]" : "mx-auto max-w-[19rem]"}>
                      <Polaroid
                        slot={slot}
                        caption={it.caption}
                        rotate={rot}
                        tape={(mi + ii) % 2 === 0 ? "butter" : "rose"}
                        onOpen={slot.type === "image" ? () => onOpenAlbum(historyAlbumItems, idx) : undefined}
                      />
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </li>
        ))}

        <li className="relative">
          <span
            aria-hidden
            className="absolute -left-[2.1rem] top-1 grid size-5 place-items-center rounded-full bg-rose ring-4 ring-cream"
          >
            <span className="size-1.5 rounded-full bg-white" />
          </span>
          <Reveal>
            <div className="paper shadow-soft rotate-1 rounded-3xl border-2 border-dashed border-rose/40 p-6 text-center">
              <span className="mx-auto grid size-12 place-items-center rounded-full bg-peach text-rose-deep">
                <Lock size={22} aria-hidden />
              </span>
              <p className="mt-3 font-hand text-3xl leading-none text-rose">Guardada para o final</p>
              <p className="mt-2 text-[0.95rem] leading-relaxed text-cocoa-soft">{duneTeaser}</p>
            </div>
          </Reveal>
        </li>
      </ol>
      <ExtraMemories onOpen={onOpenAlbum} />
    </ChapterShell>
  );
}
