import { useState } from "react";
import { demoQuirks } from "../../content/quirks";
import { ChapterShell, Card } from "../ui/ChapterShell";
import { Button } from "../ui/Button";
import { burstFrom } from "../../lib/confetti";

export function QuirksChapter() {
  const [counts, setCounts] = useState([0, 0, 0]);
  return <ChapterShell number="Capítulo 03" title="Pequenas peculiaridades" intro="Características inventadas de um personagem criativo. Toque para descobrir a resposta.">
    {demoQuirks.map((q, i) => <Card key={q.title}><h3 className="font-display text-2xl">{q.title}</h3>{counts[i] > 0 && <p className="animate-fade-up my-4" aria-live="polite">{q.text} · Ativações: {counts[i]}</p>}<Button className="mt-4" variant="butter" onClick={e => { setCounts(v => v.map((n, j) => j === i ? n + 1 : n)); burstFrom(e.currentTarget, { count: 12 }); }}>Experimentar</Button></Card>)}
  </ChapterShell>;
}
