import { useState } from "react";
import { Heart, Lock, Shuffle } from "lucide-react";
import { reasons, reasonsIntro } from "../../content/emotion";
import { burst, burstFrom, vibrate } from "../../lib/confetti";
import { cn } from "../../utils/cn";
import { Button } from "../ui/Button";
import { ChapterShell } from "../ui/ChapterShell";

export function ReasonsChapter({ onFinal }: { onFinal: () => void }) {
  const [opened, setOpened] = useState<Set<number>>(new Set());
  const [current, setCurrent] = useState<number | null>(null);

  const total = reasons.length;
  const othersOpened = [...opened].filter((n) => n !== total - 1).length;
  const unlocked = othersOpened >= total - 1;
  const lastOpen = opened.has(total - 1);

  const open = (n: number, el?: HTMLElement | null) => {
    if (n === total - 1 && !unlocked) {
      vibrate(30);
      return;
    }
    setCurrent(n);
    vibrate(10);
    setOpened((s) => {
      const next = new Set(s);
      next.add(n);
      return next;
    });
    if (n === total - 1) burst({ count: 130, emojis: ["❤️", "🤍", "✨"], y: window.innerHeight * 0.5 });
    else if (el) burstFrom(el, { count: 10, power: 0.5 });
  };

  const surprise = (el: HTMLElement) => {
    const pool = reasons.map((_, i) => i).filter((i) => !opened.has(i) && (i !== total - 1 || unlocked));
    if (pool.length === 0) return;
    open(pool[Math.floor(Math.random() * pool.length)], el);
  };

  const isFinal = current === total - 1;

  return (
    <ChapterShell number="Capítulo 08" title="28 cartões de celebração" intro={reasonsIntro}>
      <div
        className={cn(
          "grid min-h-[12rem] place-items-center rounded-3xl p-6 text-center shadow-soft ring-1 transition-colors duration-500",
          isFinal ? "bg-rose text-white ring-rose-deep" : current === null ? "paper ring-cocoa/5" : "bg-white ring-rose/20",
        )}
        aria-live="polite"
      >
        {current === null ? (
          <div className="text-cocoa-soft">
            <Heart size={30} className="mx-auto text-rose" aria-hidden />
            <p className="mt-2 font-display text-lg">Toque em um número para abrir o motivo.</p>
          </div>
        ) : (
          <div key={current} className="animate-pop">
            <p className={cn("font-hand text-4xl leading-none", isFinal ? "text-butter" : "text-rose")}>Motivo {current + 1}</p>
            <p className={cn("mt-3 font-display font-medium leading-snug [text-wrap:balance]", isFinal ? "text-[1.3rem]" : "text-[1.4rem]")}>
              {reasons[current]}
            </p>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between gap-3">
        <p className="text-sm font-bold text-cocoa-soft" aria-live="polite">
          {opened.size}/{total} abertos
        </p>
        <Button
          variant="butter"
          icon={<Shuffle size={16} aria-hidden />}
          disabled={opened.size >= total}
          onClick={(e) => surprise(e.currentTarget)}
          className="min-h-11 px-4 py-2"
        >
          Surpreenda-me
        </Button>
      </div>

      <div className="h-2 overflow-hidden rounded-full bg-white/70" aria-hidden>
        <div className="h-full rounded-full bg-gradient-to-r from-butter to-rose transition-all duration-500" style={{ width: `${(opened.size / total) * 100}%` }} />
      </div>

      <ul className="grid grid-cols-4 gap-2.5">
        {reasons.map((_, n) => {
          const isLast = n === total - 1;
          const isOpen = opened.has(n);
          const locked = isLast && !unlocked;
          return (
            <li key={n}>
              <button
                type="button"
                onClick={(e) => open(n, e.currentTarget)}
                aria-label={locked ? "Motivo 28, bloqueado até abrir todos os outros" : `Motivo ${n + 1}${isOpen ? " (aberto)" : ""}`}
                aria-disabled={locked}
                className={cn(
                  "relative grid aspect-square w-full place-items-center rounded-2xl font-display text-xl font-bold transition-all active:scale-90",
                  current === n && "scale-105 ring-4 ring-butter",
                  locked
                    ? "border-2 border-dashed border-rose/40 bg-white/40 text-rose/60"
                    : isOpen
                      ? isLast
                        ? "bg-rose text-white shadow-soft"
                        : "bg-rose/90 text-white shadow-soft"
                      : "paper shadow-soft text-cocoa ring-1 ring-cocoa/10 hover:bg-peach-soft",
                  isLast && unlocked && !isOpen && "animate-pulse-soft bg-butter",
                )}
              >
                {locked ? <Lock size={18} aria-hidden /> : n + 1}
              </button>
            </li>
          );
        })}
      </ul>

      {lastOpen && (
        <div className="animate-fade-up rounded-3xl bg-butter px-6 py-6 text-center shadow-soft">
          <p className="font-display text-xl font-semibold leading-snug">Os 28 motivos foram abertos. Mas ainda falta uma coisa.</p>
          <Button variant="primary" className="mt-4" onClick={onFinal}>
            Ir para a declaração
          </Button>
        </div>
      )}
    </ChapterShell>
  );
}
