import { useEffect, useState } from "react";
import { finale } from "../../content/emotion";
import { media } from "../../content/media";
import { burst } from "../../lib/confetti";
import type { AlbumItem } from "../AlbumViewer";
import { Button } from "../ui/Button";
import { Polaroid } from "../ui/Polaroid";
import { Reveal } from "../ui/Reveal";
import { historyAlbumItems } from "./HistoryChapter";

interface Props {
  onOpenAlbum: (items: AlbumItem[], start: number) => void;
  onChallenge: () => void;
  active: boolean;
}

export function FinalChapter({ onOpenAlbum, onChallenge, active }: Props) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!open || !active || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const layer = document.createElement("div"); layer.setAttribute("aria-hidden", "true"); layer.className = "birthday-confetti-layer";
    for (let i = 0; i < 38; i++) { const e = document.createElement("span"); e.textContent = ["✦", "●", "♥"][i % 3]; e.style.left = `${Math.random() * 100}vw`; e.style.color = ["#B76D75", "#E9B95B", "#F5D7CF"][i % 3]; e.style.animationDelay = `${-Math.random() * 8}s`; e.style.animationDuration = `${5 + Math.random() * 4}s`; layer.append(e); }
    document.body.append(layer); return () => layer.remove();
  }, [open, active]);

  const album: AlbumItem[] = [...historyAlbumItems, { slot: "favorite", caption: "Composição da demonstração." }];

  return (
    <section className="animate-fade-up mx-auto w-full max-w-xl px-5 pb-12 pt-5" aria-label={finale.title}>
      <p className="text-center font-hand text-[1.7rem] leading-none text-rose">Capítulo 09</p>
      <h2 className="mt-1 text-center font-display text-[2.7rem] font-semibold leading-[1.02] tracking-tight [text-wrap:balance]">
        {finale.title}
      </h2>

      <div className="mx-auto mt-8 max-w-[22rem]">
        <Polaroid
          slot={media.favorite}
          caption="Uma composição para o encerramento"
          rotate={-1.5}
          tape="rose"
          priority
          onOpen={() => onOpenAlbum(album, album.length - 1)}
          className="p-3.5 pb-5"
        />
      </div>

      {!open && (
        <div className="mt-8 text-center">
          <Button
            variant="rose"
            className="min-h-14 px-8 text-base"
            onClick={(e) => {
              setOpen(true);
              const r = e.currentTarget.getBoundingClientRect();
              burst({ count: 90, x: r.left + r.width / 2, y: r.top, emojis: ["🤍", "✨"] });
            }}
          >
            {finale.openButton}
          </Button>
        </div>
      )}

      {open && (
        <div className="mt-10 space-y-8">
          <article className="paper shadow-soft relative rounded-3xl p-6 ring-1 ring-rose/15 sm:p-8" aria-label="Declaração">
            <span aria-hidden className="tape" style={{ top: -10, left: 28, transform: "rotate(-6deg)" }} />
            <p className="mb-6 font-display text-3xl font-semibold italic text-rose-deep">Olá, Alex,</p>
            <div className="space-y-5">
              {finale.letter.map((p, i) => (
                <Reveal key={i} delay={i === 0 ? 0 : 60}>
                  <p
                    className={
                      p === "Eu torço pelos seus sonhos, Alex."
                        ? "font-display text-2xl font-semibold text-rose-deep"
                        : "text-[1.06rem] leading-[1.75] text-cocoa"
                    }
                  >
                    {p}
                  </p>
                </Reveal>
              ))}
            </div>
            <Reveal className="mt-8 text-right">
              <p className="font-hand text-3xl text-rose">{finale.signature}</p>
            </Reveal>
          </article>

          <Reveal>
            <div className="rounded-3xl bg-rose px-6 py-9 text-center text-white shadow-soft">
              <p className="font-display text-[2rem] font-bold leading-tight [text-wrap:balance]">{finale.finalPhrase[0]}</p>
              <p className="mt-4 font-display text-[1.2rem] leading-snug text-white/95">{finale.finalPhrase[1]}</p>
              <p className="mt-3 font-display text-[1.2rem] leading-snug text-white/95">{finale.finalPhrase[2]}</p>
              <p className="mt-5 font-display text-3xl font-bold text-butter">{finale.finalPhrase[3]}</p>
            </div>
          </Reveal>

          <Reveal>
            <p className="rounded-2xl bg-butter-soft px-5 py-4 text-center text-[0.95rem] italic leading-relaxed ring-1 ring-butter/40">{finale.ps}</p>
          </Reveal>


          <Reveal>
            <div className="rounded-3xl bg-butter-soft p-6 text-center ring-1 ring-butter/40">
              <p className="font-hand text-3xl text-rose">A experiência ainda tem uma última interação.</p>
              <p className="mt-3 leading-relaxed">Explore um desafio curto, com controles por teclado, botões e gestos. Ao coletar os dez corações, uma mensagem encerra a demonstração.</p>
              <Button variant="butter" block className="mt-5" onClick={onChallenge}>Experimentar o minijogo →</Button>
            </div>
          </Reveal>
        </div>
      )}
    </section>
  );
}

