import { Images, RotateCcw } from "lucide-react";
import { SnakeGame } from "../SnakeGame";
import type { AlbumItem } from "../AlbumViewer";
import { Button } from "../ui/Button";
import { historyAlbumItems } from "./HistoryChapter";
import { ChapterShell } from "../ui/ChapterShell";
export function GiftChapter({active,onOpenAlbum,onRestart}:{active:boolean;onOpenAlbum:(items:AlbumItem[],start:number)=>void;onRestart:()=>void}) {
  return <ChapterShell number="Último capítulo" title="Uma última interação" intro="Um minijogo conclui a experiência. Colete dez corações e descubra a mensagem fictícia de conclusão."><SnakeGame active={active}/><div className="flex flex-col gap-3 pt-5"><Button variant="primary" block icon={<Images size={18}/>} onClick={()=>onOpenAlbum(historyAlbumItems,0)}>Rever a galeria</Button><Button variant="ghost" block icon={<RotateCcw size={18}/>} onClick={onRestart}>Recomeçar a demonstração</Button></div></ChapterShell>;
}
