import { useState } from "react";
import { Building2 } from "lucide-react";
import { businesses, absurdIdeas, storeScanner, hyperfocus, holdingQuote } from "../../content/holding";
import { ChapterShell, Card, PullQuote } from "../ui/ChapterShell";
import { Button } from "../ui/Button";

export function HoldingChapter() {
  const [open, setOpen] = useState<string | null>(null);
  const [idea, setIdea] = useState(-1), [scan, setScan] = useState(-1), [focus, setFocus] = useState(0);
  return <ChapterShell number="Capítulo 02" title="Laboratório de ideias" intro="Um painel de projetos inventados para explorar estados, escolhas e revelações.">
    <div className="rounded-3xl bg-cocoa p-6 text-cream"><Building2 className="mb-3 text-butter" size={32}/><h3 className="font-display text-2xl">ALEX LAB</h3><p className="mt-2 text-sm">Todo negócio aqui faz parte da ficção.</p></div>
    {businesses.map(b => <Card key={b.id}><button className="min-h-12 w-full text-left" onClick={() => setOpen(open === b.id ? null : b.id)} aria-expanded={open === b.id}><span className="font-display text-xl">{b.name}</span><span className="mt-2 block text-sm text-rose">{b.status}</span></button>{open === b.id && <p className="animate-fade-up mt-3">{b.note}</p>}</Card>)}
    <Card><h3 className="font-display text-2xl">Gerador de possibilidades</h3>{idea >= 0 && <div className="animate-pop my-4 rounded-2xl bg-butter-soft p-4" aria-live="polite"><b>{absurdIdeas[idea].name}</b><p>{absurdIdeas[idea].note}</p></div>}<Button className="mt-4" variant="butter" onClick={() => setIdea(n => (n + 1) % absurdIdeas.length)}>Inventar uma ideia</Button></Card>
    <Card><h3 className="font-display text-2xl">Um lugar, uma ideia</h3><div className="my-4 flex flex-wrap gap-2">{storeScanner.map((s, i) => <Button key={s.id} variant="ghost" onClick={() => setScan(i)}>{s.emoji} {s.label}</Button>)}</div>{scan >= 0 && <p role="status">{storeScanner[scan].thought}</p>}</Card>
    <Card><h3 className="font-display text-2xl">Interesse da semana</h3><p className="my-4 font-hand text-3xl text-rose" aria-live="polite">{hyperfocus[focus].topic}</p><Button variant="ghost" onClick={() => setFocus(n => (n + 1) % hyperfocus.length)}>Trocar de assunto</Button></Card>
    <PullQuote>{holdingQuote}</PullQuote>
  </ChapterShell>;
}
