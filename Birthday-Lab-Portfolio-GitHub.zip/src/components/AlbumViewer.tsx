import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { media, type MediaKey } from "../content/media";
import { MediaFrame } from "./ui/MediaFrame";

export interface AlbumItem {
  slot: MediaKey;
  caption: string;
}

interface Props {
  items: AlbumItem[];
  startIndex: number;
  onClose: () => void;
}

/** Álbum de memórias em tela cheia: setas, teclado e deslizar com o dedo */
export function AlbumViewer({ items, startIndex, onClose }: Props) {
  const [index, setIndex] = useState(startIndex);
  const touchX = useRef<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  const go = useCallback(
    (dir: number) => setIndex((i) => (i + dir + items.length) % items.length),
    [items.length],
  );

  useEffect(() => {
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [go, onClose]);

  const item = items[index];
  if (!item) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Álbum de memórias"
      className="animate-fade-in fixed inset-0 z-[70] flex flex-col bg-cocoa/90 backdrop-blur-sm"
      onTouchStart={(e) => (touchX.current = e.touches[0].clientX)}
      onTouchEnd={(e) => {
        if (touchX.current === null) return;
        const dx = e.changedTouches[0].clientX - touchX.current;
        if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1);
        touchX.current = null;
      }}
    >
      <div className="flex items-center justify-between px-4 pb-2 pt-[max(1rem,env(safe-area-inset-top))] text-cream">
        <span className="font-hand text-2xl">
          {index + 1} / {items.length}
        </span>
        <button
          ref={closeRef}
          type="button"
          onClick={onClose}
          className="grid size-11 place-items-center rounded-full bg-cream/15 hover:bg-cream/25"
          aria-label="Fechar álbum"
        >
          <X size={22} />
        </button>
      </div>

      <div className="flex min-h-0 flex-1 items-center justify-center overflow-y-auto px-4 py-2">
        <figure key={index} className="animate-pop paper shadow-polaroid w-full max-w-sm rounded-[3px] p-3 pb-4">
          <div className="overflow-hidden rounded-[2px] bg-peach-soft">
            <MediaFrame slot={media[item.slot]} alt={item.caption} className="max-h-[62dvh] object-contain" />
          </div>
          <figcaption className="mt-3 text-center font-hand text-2xl leading-6">{item.caption}</figcaption>
        </figure>
      </div>

      <div className="flex items-center justify-center gap-6 px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-3 text-cream">
        <button
          type="button"
          onClick={() => go(-1)}
          className="grid size-12 place-items-center rounded-full bg-cream/15 hover:bg-cream/25"
          aria-label="Foto anterior"
        >
          <ChevronLeft size={24} />
        </button>
        <div className="flex max-w-[50vw] flex-wrap justify-center gap-1.5" aria-hidden="true">
          {items.map((_, i) => (
            <span key={i} className={`h-1.5 rounded-full transition-all ${i === index ? "w-5 bg-butter" : "w-1.5 bg-cream/40"}`} />
          ))}
        </div>
        <button
          type="button"
          onClick={() => go(1)}
          className="grid size-12 place-items-center rounded-full bg-cream/15 hover:bg-cream/25"
          aria-label="Próxima foto"
        >
          <ChevronRight size={24} />
        </button>
      </div>
    </div>
  );
}
