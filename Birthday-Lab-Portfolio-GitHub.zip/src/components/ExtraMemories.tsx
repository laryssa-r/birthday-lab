import type { AlbumItem } from "./AlbumViewer";
import { media } from "../content/media";
import { Button } from "./ui/Button";
import { Polaroid } from "./ui/Polaroid";
export const extraItems: AlbumItem[] = [{slot:"albumA",caption:"Estudo de cor e forma."},{slot:"albumB",caption:"Estudo de luz e ritmo."}];
export function ExtraMemories({onOpen}:{onOpen:(items:AlbumItem[],start:number)=>void}) {
  return <details className="paper rounded-3xl p-5 shadow-soft"><summary className="cursor-pointer font-hand text-3xl text-rose">Mais composições da demonstração</summary><Button className="my-5" variant="ghost" onClick={()=>onOpen(extraItems,0)}>Explorar a galeria</Button><div className="grid gap-7 sm:grid-cols-2">{extraItems.map((item,i)=><Polaroid key={item.slot} slot={media[item.slot]} caption={item.caption} onOpen={()=>onOpen(extraItems,i)}/>)}</div></details>;
}
