import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "../../utils/cn";

interface Props {
  number: string;
  title: string;
  intro?: ReactNode;
  children: ReactNode;
  className?: string;
}

export function ChapterShell({ number, title, intro, children, className }: Props) {
  return (
    <section className={cn("animate-fade-up mx-auto w-full max-w-xl px-5 pb-10 pt-5", className)} aria-label={title}>
      <p className="font-hand text-[1.7rem] leading-none text-rose">{number}</p>
      <h2 className="mt-1 font-display text-[2.5rem] font-semibold leading-[1.02] tracking-tight text-cocoa [text-wrap:balance]">
        {title}
      </h2>
      {intro && <div className="mt-3 text-[1.02rem] leading-relaxed text-cocoa-soft">{intro}</div>}
      <div className="mt-6 space-y-6">{children}</div>
    </section>
  );
}

/** Cartão de papel padrão */
export function Card({
  children,
  className,
  ...rest
}: { children: ReactNode; className?: string } & HTMLAttributes<HTMLDivElement>) {
  return (
    <div {...rest} className={cn("paper shadow-soft rounded-3xl p-5 ring-1 ring-cocoa/5", className)}>
      {children}
    </div>
  );
}

/** Frase de destaque (citação) */
export function PullQuote({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <blockquote
      className={cn(
        "relative rounded-3xl bg-butter-soft px-6 py-6 font-display text-[1.35rem] font-medium italic leading-snug text-cocoa ring-1 ring-butter/40",
        className,
      )}
    >
      <span aria-hidden="true" className="absolute -top-3 left-5 font-display text-6xl leading-none text-butter">
        “
      </span>
      {children}
    </blockquote>
  );
}
