import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../../utils/cn";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "butter" | "rose" | "ghost";
  icon?: ReactNode;
  block?: boolean;
}

const variants = {
  primary: "bg-cocoa text-cream hover:bg-cocoa/90 shadow-soft",
  butter: "bg-butter text-cocoa hover:brightness-105 shadow-soft",
  rose: "bg-rose text-white hover:bg-rose-deep shadow-soft",
  ghost: "bg-white/60 text-cocoa ring-1 ring-cocoa/15 hover:bg-white",
};

export function Button({ variant = "primary", icon, block, className, children, ...rest }: Props) {
  return (
    <button
      type="button"
      {...rest}
      className={cn(
        "inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-6 py-3 text-[0.95rem] font-bold tracking-tight transition-all duration-200 active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-45",
        variants[variant],
        block && "w-full",
        className,
      )}
    >
      {icon}
      {children}
    </button>
  );
}
