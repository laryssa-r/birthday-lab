import { useState, type ReactNode } from "react";
import { cn } from "../../utils/cn";
import { vibrate } from "../../lib/confetti";

interface Props {
  front: ReactNode;
  back: ReactNode;
  label: string;
  className?: string;
  frontClassName?: string;
  backClassName?: string;
  onFlip?: (flipped: boolean) => void;
}

/** Cartão que vira ao toque. As duas faces ocupam a mesma célula, então a altura é a maior das duas. */
export function FlipCard({ front, back, label, className, frontClassName, backClassName, onFlip }: Props) {
  const [flipped, setFlipped] = useState(false);
  return (
    <button
      type="button"
      className={cn("flip-scene block w-full text-left", className)}
      aria-pressed={flipped}
      aria-label={label}
      onClick={() => {
        const next = !flipped;
        setFlipped(next);
        vibrate(10);
        onFlip?.(next);
      }}
    >
      <span className={cn("flip-inner", flipped && "is-flipped")}>
        <span className={cn("flip-face block rounded-2xl", frontClassName)} aria-hidden={flipped}>
          {front}
        </span>
        <span className={cn("flip-face flip-back block rounded-2xl", backClassName)} aria-hidden={!flipped}>
          {back}
        </span>
      </span>
    </button>
  );
}
