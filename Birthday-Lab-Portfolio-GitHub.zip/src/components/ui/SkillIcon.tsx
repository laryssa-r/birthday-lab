import {
  BrickWall,
  ChefHat,
  Croissant,
  Goal,
  Layers,
  PaintRoller,
  Volleyball,
  Waves,
  Wrench,
  Zap,
} from "lucide-react";
import type { SkillIcon as SkillIconName } from "../../content/who";

const map = {
  paint: PaintRoller,
  pipe: Wrench,
  build: BrickWall,
  bolt: Zap,
  gesso: Layers,
  chef: ChefHat,
  soccer: Goal,
  volley: Volleyball,
  futevolei: Waves,
  bakery: Croissant,
};

export function SkillIcon({ name, size = 26 }: { name: SkillIconName; size?: number }) {
  const Icon = map[name];
  return <Icon size={size} strokeWidth={1.8} aria-hidden />;
}
