import { useState } from "react";
import { Camera, Film } from "lucide-react";
import { siteConfig, type MediaSlot } from "../../content/media";
import { cn } from "../../utils/cn";

interface Props {
  slot: MediaSlot;
  alt: string;
  className?: string;
  /** se informado e for imagem, o clique abre (ex.: álbum) */
  onOpen?: () => void;
  priority?: boolean;
}

/**
 * Exibe foto ou vídeo real SEM distorcer: a mídia usa a proporção original.
 * Se o arquivo não existir, mostra um espaço reservado (ou nada, conforme siteConfig).
 */
export function MediaFrame({ slot, alt, className, onOpen, priority }: Props) {
  const [failed, setFailed] = useState(false);
  const ratio = slot.ratio ?? 4 / 5;

  if (!slot.src) return null;
  if (failed) {
    if (!siteConfig.showPlaceholders) return null;
    return (
      <div
        className={cn(
          "relative flex w-full flex-col items-center justify-center gap-2 overflow-hidden bg-gradient-to-br from-peach to-butter-soft p-4 text-center text-cocoa",
          className,
        )}
        style={{ aspectRatio: String(ratio) }}
        role="img"
        aria-label={`Espaço reservado: ${slot.hint}`}
      >
        <div className="absolute inset-2 rounded-sm border-2 border-dashed border-cocoa/25" />
        <span className="text-4xl" aria-hidden="true">
          {slot.emoji ?? "📷"}
        </span>
        <span className="relative max-w-[16rem] text-sm font-semibold leading-snug">{slot.hint}</span>
        <span className="relative flex items-center gap-1 rounded-full bg-cream/70 px-2.5 py-1 text-[10px] font-medium text-cocoa-soft">
          {slot.type === "video" ? <Film size={12} aria-hidden /> : <Camera size={12} aria-hidden />}
          public/media/{slot.src.replace("./media/", "")}
        </span>
      </div>
    );
  }

  if (slot.type === "video") {
    return (
      <video
        className={cn("block max-h-[72dvh] w-full bg-cocoa object-contain", className)}
        style={{ aspectRatio: `auto ${ratio}` }}
        src={slot.src}
        poster={slot.poster}
        controls
        playsInline
        preload="metadata"
        aria-label={alt}
        onError={() => setFailed(true)}
      />
    );
  }

  const img = (
    <img
      className={cn("block h-auto w-full", className)}
      style={{ aspectRatio: `auto ${ratio}` }}
      src={slot.src}
      alt={alt}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      draggable={false}
      onError={() => setFailed(true)}
    />
  );

  if (onOpen) {
    return (
      <button
        type="button"
        onClick={onOpen}
        className="block w-full cursor-zoom-in"
        aria-label={`Ampliar: ${alt}`}
      >
        {img}
      </button>
    );
  }
  return img;
}
