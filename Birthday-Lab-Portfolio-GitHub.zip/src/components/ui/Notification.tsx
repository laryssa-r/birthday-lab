import type { ReactNode } from "react";
import { cn } from "../../utils/cn";

interface Props {
  app: string;
  title: string;
  body?: string;
  icon: ReactNode;
  className?: string;
  tone?: "light" | "warn";
}

/** Falsa notificação estilo celular */
export function Notification({ app, title, body, icon, className, tone = "light" }: Props) {
  return (
    <div
      role="status"
      className={cn(
        "animate-slide-down flex items-start gap-3 rounded-2xl p-3.5 shadow-soft ring-1 backdrop-blur",
        tone === "warn" ? "bg-butter-soft/95 ring-butter/60" : "bg-white/90 ring-cocoa/10",
        className,
      )}
    >
      <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-cocoa text-butter">{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between text-[0.7rem] font-bold uppercase tracking-wider text-cocoa-soft">
          <span>{app}</span>
          <span className="font-medium normal-case tracking-normal">agora</span>
        </div>
        <p className="mt-0.5 text-[0.95rem] font-bold leading-snug">{title}</p>
        {body && <p className="mt-0.5 text-sm leading-snug text-cocoa-soft">{body}</p>}
      </div>
    </div>
  );
}
