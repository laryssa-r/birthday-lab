import type { MediaSlot } from "../../content/media";
import { cn } from "../../utils/cn";
import { MediaFrame } from "./MediaFrame";

interface Props {
  slot: MediaSlot;
  caption: string;
  rotate?: number;
  tape?: "butter" | "rose" | "none";
  className?: string;
  onOpen?: () => void;
  priority?: boolean;
}

/** Polaroide digital com fita adesiva. Preserva a proporção da foto. */
export function Polaroid({ slot, caption, rotate = 0, tape = "butter", className, onOpen, priority }: Props) {
  if (!slot.src) return null;
  return (
    <figure
      className={cn("paper shadow-polaroid relative mx-auto w-full rounded-[3px] p-3 pb-4", className)}
      style={{ transform: `rotate(${rotate}deg)` }}
    >
      {tape !== "none" && (
        <span
          className={cn("tape", tape === "rose" && "rose")}
          style={{ top: -10, left: "50%", transform: "translateX(-50%) rotate(-3deg)" }}
          aria-hidden="true"
        />
      )}
      <div className="overflow-hidden rounded-[2px] bg-peach-soft">
        <MediaFrame slot={slot} alt={caption} onOpen={onOpen} priority={priority} />
      </div>
      <figcaption className="mt-3 px-1 text-center font-hand text-[1.4rem] leading-6 text-cocoa">{caption}</figcaption>
    </figure>
  );
}
