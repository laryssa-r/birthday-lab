export const sheet = [
  {
    "label": "Nome",
    "value": "Alex — personagem fictício"
  },
  {
    "label": "Idade",
    "value": "28 anos (demonstração)"
  },
  {
    "label": "Perfil",
    "value": "Curioso e criativo"
  },
  {
    "label": "Time",
    "value": "Equipe das boas ideias"
  },
  {
    "label": "Profissão",
    "value": "Designer de experiências"
  },
  {
    "label": "Especialidade",
    "value": "Testar possibilidades e aprender fazendo"
  }
];
export const realTraits = [
  "Curioso",
  "Criativo",
  "Colaborativo",
  "Persistente"
];
export type SkillIcon = "paint" | "pipe" | "build" | "bolt" | "gesso" | "chef" | "soccer" | "volley" | "futevolei" | "bakery";
export const skills: {id:string;name:string;icon:SkillIcon;back:string}[] = [
  {
    "id": "visual",
    "name": "Design visual",
    "icon": "paint",
    "back": "Paletas, composição e atenção aos detalhes."
  },
  {
    "id": "prototype",
    "name": "Prototipação",
    "icon": "build",
    "back": "Uma ideia ganha forma para ser testada."
  },
  {
    "id": "logic",
    "name": "Lógica",
    "icon": "bolt",
    "back": "Um problema de cada vez, com curiosidade."
  },
  {
    "id": "collab",
    "name": "Colaboração",
    "icon": "volley",
    "back": "Boas experiências nascem da troca."
  },
  {
    "id": "food",
    "name": "Cozinha criativa",
    "icon": "chef",
    "back": "Receitas fictícias, muita experimentação."
  },
  {
    "id": "new",
    "name": "Aprendizado",
    "icon": "gesso",
    "back": "Sempre há uma habilidade nova para explorar."
  }
];
export const professionsOfTheDay = [
  "Explorador de interfaces",
  "Colecionador de referências",
  "Inventor de rascunhos",
  "Testador de protótipos"
];
export const whoQuote = "Uma ideia fica mais interessante quando alguém resolve experimentá-la.";

