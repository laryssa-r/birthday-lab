import type {MediaKey} from "./media";
export interface Memory {id:string;num:string;title:string;text:string;items:{slot:MediaKey;caption:string}[];}
export const historyIntro = "Uma linha do tempo inteiramente fictícia. As ilustrações substituem fotografias e os clipes são animações abstratas criadas para esta demonstração.";
export const memories: Memory[] = [
  {
    "id": "begin",
    "num": "Cena 01",
    "title": "Uma ideia no papel",
    "text": "Todo projeto começa com um primeiro rascunho. Aqui, ele vira uma cena interativa.",
    "items": [
      {
        "slot": "beginning",
        "caption": "Animação original da demonstração."
      }
    ]
  },
  {
    "id": "trip",
    "num": "Cena 02",
    "title": "Um caminho novo",
    "text": "Uma viagem inventada para explorar ritmo, contraste e transições.",
    "items": [
      {
        "slot": "tripPhoto",
        "caption": "Paisagem abstrata — ilustração."
      }
    ]
  },
  {
    "id": "coast",
    "num": "Cena 03",
    "title": "Uma pausa perto do mar",
    "text": "Um momento imaginado para desacelerar a narrativa.",
    "items": [
      {
        "slot": "beach",
        "caption": "Mar ilustrado, sem local real."
      }
    ]
  },
  {
    "id": "coffee",
    "num": "Cena 04",
    "title": "Entre conversas e café",
    "text": "Pequenos detalhes dão personalidade à história.",
    "items": [
      {
        "slot": "coffee",
        "caption": "Composição gráfica de uma pausa."
      }
    ]
  },
  {
    "id": "celebrate",
    "num": "Cena 05",
    "title": "Celebrar o caminho",
    "text": "O capítulo termina com espaço para imaginar o próximo passo.",
    "items": [
      {
        "slot": "celebration",
        "caption": "Cena fictícia de celebração."
      }
    ]
  }
];
export const duneTeaser = "Uma composição especial está reservada para o encerramento.";
