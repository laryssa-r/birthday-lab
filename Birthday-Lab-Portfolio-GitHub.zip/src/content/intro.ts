export const gate = {
  "robotLabel": "BIRTHDAY LAB · DEMONSTRAÇÃO",
  "greeting": "Olá, Alex.",
  "lines": [
    "Uma experiência fictícia para explorar design, narrativa e interação."
  ],
  "version": "ALEX 2.8",
  "recipient": "Visitante da demonstração",
  "classification": "Conteúdo fictício",
  "before": "Confirme a identidade do personagem para conhecer o fluxo.",
  "question": "Alex é conhecido por…",
  "options": [
    "Colecionar cadernos de ideias.",
    "Transformar uma pausa para café em um novo projeto.",
    "Querer testar todas as ferramentas criativas.",
    "Comemorar pequenas conquistas."
  ],
  "hint": "Marque pelo menos uma opção para experimentar a entrada.",
  "button": "Confirmar identidade",
  "footer": "Esta verificação faz parte da demonstração. Não é autenticação."
};
export const loadingSteps = [
  "Verificando personagem fictício…",
  "Organizando as ideias…",
  "Preparando as interações…",
  "Experiência disponível!"
];
export const title = {
  "eyebrow": "Design que vira experiência",
  "main": "ALEX 2.8",
  "sub": "Edição demonstrativa",
  "tagline": "28 anos fictícios, ideias demais e uma surpresa interativa.",
  "notes": [
    "O que você pode explorar:",
    "Capítulos com progresso",
    "Cartões e pequenas surpresas",
    "Galeria ilustrada e jogo final"
  ],
  "button": "Explorar a demonstração"
};
