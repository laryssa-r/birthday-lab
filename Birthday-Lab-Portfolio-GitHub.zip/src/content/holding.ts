export type BizStatus = "real" | "analysis" | "study" | "waiting";
export const businesses: {id:string;name:string;status:string;kind:BizStatus;note:string}[] = [{"id": "studio", "name": "Estúdio de ideias", "status": "Projeto fictício", "kind": "real", "note": "Um laboratório criativo para esta demonstração."}, {"id": "cafe", "name": "Café de protótipos", "status": "Em análise", "kind": "analysis", "note": "Desenhar interfaces enquanto o café passa."}, {"id": "shop", "name": "Loja de cadernos", "status": "Em estudo", "kind": "study", "note": "Uma ideia inventada para demonstrar o painel."}, {"id": "next", "name": "Próxima ideia", "status": "A descobrir", "kind": "waiting", "note": "O botão abaixo inventa mais uma possibilidade."}];
export const absurdIdeas = [
  {
    "name": "Biblioteca de rascunhos",
    "note": "Nenhuma ideia precisa nascer pronta."
  },
  {
    "name": "Museu do botão perfeito",
    "note": "Exposição temporária de estados de hover."
  },
  {
    "name": "Café com oficina de protótipos",
    "note": "Papel, conversa e testes rápidos."
  }
];
export const storeScanner = [
  {
    "id": "cafe",
    "label": "Café",
    "emoji": "☕",
    "thought": "E se cada mesa tivesse um caderno de ideias?"
  },
  {
    "id": "livraria",
    "label": "Livraria",
    "emoji": "📚",
    "thought": "Daria para fazer uma oficina de histórias aqui."
  },
  {
    "id": "parque",
    "label": "Parque",
    "emoji": "🌿",
    "thought": "Um lugar para observar e imaginar novas possibilidades."
  }
];
export const hyperfocus = [
  {
    "topic": "Tipografia experimental",
    "power": 90,
    "days": "uma semana"
  },
  {
    "topic": "Fotografia abstrata",
    "power": 75,
    "days": "três tardes"
  },
  {
    "topic": "Jogos de lógica",
    "power": 95,
    "days": "até resolver o desafio"
  }
];
export const holdingQuote = "Todas as empresas e situações deste painel são inventadas para a demonstração.";
