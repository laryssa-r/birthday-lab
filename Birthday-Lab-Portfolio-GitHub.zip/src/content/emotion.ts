import type {MediaKey} from "./media";
export const admireIntro = {
  "title": "Uma mudança de ritmo",
  "text": "A experiência desacelera para apresentar mensagens de reconhecimento fictícias.",
  "button": "Explorar a sequência"
};
export const admireSteps: {slot:MediaKey;kicker:string;text:string}[] = [{"slot": "inspire1", "kicker": "Curiosidade", "text": "Uma nova pergunta pode abrir um caminho inesperado."}, {"slot": "inspire2", "kicker": "Iniciativa", "text": "O primeiro protótipo não precisa ser perfeito para ensinar algo."}, {"slot": "inspire3", "kicker": "Colaboração", "text": "Uma boa ideia ganha novas formas quando é compartilhada."}, {"slot": "inspire4", "kicker": "Futuro", "text": "Cada pequeno aprendizado oferece uma possibilidade para amanhã."}];
export const admireClosing = "Reconhecer o caminho percorrido também é parte de imaginar o futuro.";
export const reasonsIntro = "28 mensagens fictícias em cartões interativos. Abra os primeiros para liberar o último.";
export const reasons = [
  "Pela curiosidade de aprender.",
  "Pela disposição de experimentar.",
  "Pela criatividade nos detalhes.",
  "Pelo cuidado com as pessoas.",
  "Por colaborar nas ideias.",
  "Por ouvir outros pontos de vista.",
  "Por saber recomeçar.",
  "Pela coragem de testar.",
  "Pelo bom humor.",
  "Pela paciência com o processo.",
  "Por celebrar pequenos avanços.",
  "Pelo entusiasmo com uma descoberta.",
  "Por compartilhar o que aprende.",
  "Por fazer boas perguntas.",
  "Por observar o mundo.",
  "Por transformar referências em ideias.",
  "Por respeitar o tempo dos outros.",
  "Pela energia criativa.",
  "Por valorizar uma pausa.",
  "Por dar atenção a um detalhe.",
  "Por imaginar possibilidades.",
  "Por trazer leveza para o trabalho.",
  "Por acolher uma sugestão.",
  "Por aprender com um erro.",
  "Por persistir no que importa.",
  "Por criar em conjunto.",
  "Por querer ir além.",
  "Porque boas histórias merecem novos capítulos."
];
export const finale = {
  "title": "Feliz novo ciclo, Alex",
  "openButton": "Abrir a mensagem de demonstração",
  "letter": [
    "Esta mensagem é um exemplo fictício de encerramento. Em um projeto personalizado, este espaço pode receber um texto autorizado pelo destinatário.",
    "Que o próximo ciclo tenha boas descobertas, tempo para criar e oportunidades para aprender com outras pessoas.",
    "Mais do que chegar a um resultado, vale reconhecer cada tentativa que tornou o caminho possível.",
    "Esta demonstração mostra como texto, ritmo, imagem e interação podem transformar uma mensagem simples em uma experiência."
  ],
  "finalPhrase": [
    "Um novo ciclo.",
    "Novas ideias para explorar.",
    "E boas histórias para construir.",
    "Que venham os próximos capítulos!"
  ],
  "ps": "Personagem, mensagens e cenas criados para demonstração. Nenhuma história pessoal está publicada aqui.",
  "videoTitle": "Cena demonstrativa",
  "videoText": "Animação gráfica original.",
  "signature": "Equipe Aurora — personagem fictício"
};
