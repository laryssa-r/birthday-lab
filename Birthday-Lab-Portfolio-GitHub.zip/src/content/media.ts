export interface MediaSlot {id:string;type:"image"|"video";src:string;hint:string;ratio?:number;poster?:string;emoji?:string;}
export const siteConfig = {
  "showPlaceholders": false,
  "musicSrc": "./media/audio/demo.wav",
  "recipient": "Alex",
  "author": "Equipe Aurora"
};
export const media = {
  avatar: {id:"avatar",type:"image",src:"./media/illustrations/avatar.svg",hint:"Ilustração fictícia",ratio:4/5},
  team: {id:"team",type:"image",src:"./media/illustrations/team.svg",hint:"Ilustração fictícia",ratio:4/5},
  skyline: {id:"skyline",type:"image",src:"./media/illustrations/skyline.svg",hint:"Ilustração fictícia",ratio:4/5},
  party: {id:"party",type:"image",src:"./media/illustrations/party.svg",hint:"Ilustração fictícia",ratio:4/5},
  pet: {id:"pet",type:"image",src:"./media/illustrations/pet.svg",hint:"Ilustração fictícia",ratio:4/5},
  kitchen: {id:"kitchen",type:"image",src:"./media/illustrations/kitchen.svg",hint:"Ilustração fictícia",ratio:4/5},
  beginning: {id:"beginning",type:"video",src:"./media/video/beginning.mp4",poster:"./media/illustrations/beginning.svg",hint:"Ilustração fictícia",ratio:4/5},
  tripClip: {id:"tripClip",type:"image",src:"./media/illustrations/tripClip.svg",hint:"Ilustração fictícia",ratio:4/5},
  tripPhoto: {id:"tripPhoto",type:"image",src:"./media/illustrations/tripPhoto.svg",hint:"Ilustração fictícia",ratio:4/5},
  beach: {id:"beach",type:"image",src:"./media/illustrations/beach.svg",hint:"Ilustração fictícia",ratio:4/5},
  coffee: {id:"coffee",type:"image",src:"./media/illustrations/coffee.svg",hint:"Ilustração fictícia",ratio:4/5},
  celebration: {id:"celebration",type:"image",src:"./media/illustrations/celebration.svg",hint:"Ilustração fictícia",ratio:4/5},
  inspire1: {id:"inspire1",type:"image",src:"./media/illustrations/inspire1.svg",hint:"Ilustração fictícia",ratio:4/5},
  inspire2: {id:"inspire2",type:"image",src:"./media/illustrations/inspire2.svg",hint:"Ilustração fictícia",ratio:4/5},
  inspire3: {id:"inspire3",type:"image",src:"./media/illustrations/inspire3.svg",hint:"Ilustração fictícia",ratio:4/5},
  inspire4: {id:"inspire4",type:"image",src:"./media/illustrations/inspire4.svg",hint:"Ilustração fictícia",ratio:4/5},
  favorite: {id:"favorite",type:"image",src:"./media/illustrations/favorite.svg",hint:"Ilustração fictícia",ratio:4/5},
  albumA: {id:"albumA",type:"image",src:"./media/illustrations/albumA.svg",hint:"Ilustração fictícia",ratio:4/5},
  albumB: {id:"albumB",type:"image",src:"./media/illustrations/albumB.svg",hint:"Ilustração fictícia",ratio:4/5},
} satisfies Record<string,MediaSlot>;
export type MediaKey = keyof typeof media;
