export const filesIntro = "Pequenas histórias inventadas para demonstrar revelações e escolhas.";
export const demoStories = [
  {
    "title": "O protótipo de papel",
    "text": "Uma ideia começou num guardanapo e virou uma tarde de testes."
  },
  {
    "title": "A receita experimental",
    "text": "A medida era uma pitada. O laboratório preferiu não especificar o tamanho."
  },
  {
    "title": "O mapa ao contrário",
    "text": "O passeio fictício ganhou uma rota inesperada e uma nova história."
  }
];
