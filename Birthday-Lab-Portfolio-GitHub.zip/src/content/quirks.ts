export const demoQuirks = [
  {
    "title": "Mais um caderno",
    "text": "A próxima grande ideia exige mais uma página em branco."
  },
  {
    "title": "Só mais um teste",
    "text": "O protótipo está pronto. Mas e se o botão fosse diferente?"
  },
  {
    "title": "Pausa para café",
    "text": "Estado de energia restaurado. Criatividade disponível."
  }
];
