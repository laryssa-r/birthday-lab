export const demoBreaks = [
  "Um minuto para respirar",
  "Uma pausa para alongar",
  "Um café sem olhar para a tela"
];
