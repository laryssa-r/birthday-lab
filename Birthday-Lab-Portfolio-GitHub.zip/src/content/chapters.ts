export interface ChapterMeta {
  id: string;
  short: string;
  title: string;
  /** cor de fundo da página neste capítulo (transição gradual para o romântico) */
  bg: string;
}

export const chapters: ChapterMeta[] = [
  { id: "quem", short: "Quem é", title: "Quem é Alex?", bg: "#FAF7F2" },
  { id: "holding", short: "Ideias", title: "Laboratório de ideias", bg: "#FBF3E2" },
  { id: "manias", short: "Manias", title: "Pequenas peculiaridades", bg: "#FBF0EA" },
  { id: "arquivos", short: "Arquivos", title: "Pequenos imprevistos", bg: "#F8EEE6" },
  { id: "spa", short: "Pausa", title: "Pausa criativa", bg: "#FAEAE4" },
  { id: "historia", short: "Uma história fictícia", title: "Uma história fictícia", bg: "#F9E4DD" },
  { id: "admiro", short: "Admiro", title: "Reconhecer o caminho", bg: "#F6DCD6" },
  { id: "motivos", short: "28 motivos", title: "28 cartões de celebração", bg: "#F4D6CF" },
  { id: "final", short: "Final", title: "Um novo ciclo", bg: "#F5D7CF" },
  { id: "presente", short: "Minijogo", title: "Desafio final", bg: "#F8EBCB" },
];
