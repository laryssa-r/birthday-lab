# Birthday Lab

Uma demonstração de experiência de aniversário com narrativa guiada, cartões interativos, galeria ilustrada, áudio opcional e um minijogo de cobrinha.

**Todos os personagens, textos e cenas desta versão são fictícios.** O projeto usa ilustrações vetoriais, uma animação abstrata e um instrumental sintético criados para a demonstração.

![Prévia da identidade visual](public/media/illustrations/favorite.svg)

## O desafio

Transformar uma mensagem de celebração em uma sequência navegável, com ritmo, humor leve e diferentes formas de interação. A experiência foi pensada para celulares, com atenção à legibilidade, aos controles por toque e à continuidade do áudio.

## O que explorar

- Entrada com confirmação lúdica e alerta animado.
- Dez capítulos, indicador de progresso e navegação direta.
- Cartões de habilidades, escolhas e revelações.
- Painel de ideias fictícias e gerador de possibilidades.
- Galeria ampliável com navegação por teclado e gestos.
- Vídeo abstrato original e música opcional, iniciada por interação.
- Mensagem final com confetes e respeito à preferência de movimento reduzido.
- Cobrinha com teclado, botões e gestos; dez corações para concluir.

## Tecnologias

React, TypeScript, Vite, Tailwind CSS e Lucide. O conteúdo fica separado dos componentes em `src/content`. A versão de publicação é um site estático.

## Processo e participação

O projeto foi desenvolvido em colaboração com assistência de IA, com direção criativa, curadoria de conteúdo, testes e refinamentos iterativos. Este repositório apresenta uma adaptação demonstrativa para portfólio. Não foram medidos resultados de conversão, satisfação ou uso real para esta demonstração.

## Rodar localmente

Requer Node.js 22.12 ou superior.

```sh
npm install
npm run dev
```

## Verificar e gerar a publicação

```sh
npm run check
npm run build
npm run preview
```

O resultado fica em `dist/`. O ZIP de publicação fornecido já contém o resultado pronto, com `index.html` na raiz.

## Publicar

No Netlify, envie a pasta `dist` ou o ZIP de publicação. Ao conectar este repositório, `netlify.toml` define o comando de build e a pasta de saída. Publique esta demonstração em um projeto separado de qualquer versão pessoal.

Para o GitHub, envie os arquivos deste repositório, incluindo `src/` e `public/`. A pasta `node_modules/` e os arquivos de ambiente estão no `.gitignore`.

## Conteúdo e privacidade

Esta cópia foi criada com uma lista explícita de arquivos de origem permitidos. Fotos, vídeos pessoais, declarações, dados de hospedagem e histórico Git da versão pessoal não foram copiados. A mídia está em `public/media` e foi feita para esta demonstração.

A confirmação de identidade da entrada é parte da interface. Ela não é um mecanismo de autenticação.

## Próximas melhorias

Testes de interação em aparelhos físicos, melhorias de gerenciamento de foco nas janelas e uma galeria com carregamento progressivo são possibilidades de evolução. A estrutura atual já inclui rótulos, estados acessíveis, controle de áudio e suporte a movimento reduzido.
